# DayZ Epoch Download Information

## Latest Version: 1.0.7.1 (Released May 25, 2023)

### Download Links:
- **Client Files**: https://drive.google.com/file/d/19iCJevU008g311vsxNR0PjYmkSv36YKv/
- **Server Files**: https://drive.google.com/file/d/1jDn86sfTwcRae4NZgHK76k_CaY1jOUP2/
- **Password for Server Files**: 123456

### Previous Versions:
- **1.0.7**: Released Apr 23, 2021
- **1.0.6.2**: Released Dec 27, 2020
- **1.0.6.1**: Released Mar 2, 2020
- **1.0.5.1**: Released Jun 25, 2019

### Installation Notes:
- Server files are password protected with "123456"
- Client and server packages are separate downloads
- Files are distributed as .7z archives
- Latest version includes updates from May 25, 2023

### Required for Docker Build:
1. Download server files from Google Drive link
2. Extract with password "123456"
3. Copy to appropriate directories in Docker build context
4. Ensure all filenames are converted to lowercase for Linux compatibility
